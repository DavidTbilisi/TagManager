from .service import print_list_tags_all_table


def handle_list_all_command(args):
    print_list_tags_all_table()